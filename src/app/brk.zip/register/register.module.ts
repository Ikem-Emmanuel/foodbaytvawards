import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RegisterRoutingModule } from './register-routing.module';
import { TranslateModule } from '@ngx-translate/core';
import { SHARED_ZORRO_MODULES } from 'src/app/shared/shared-zorro.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UserRegisterComponent } from './register.component';

@NgModule({
  declarations: [UserRegisterComponent],
  imports: [CommonModule, RegisterRoutingModule, FormsModule, ReactiveFormsModule, TranslateModule, ...SHARED_ZORRO_MODULES],
})
export class RegisterModule {}
