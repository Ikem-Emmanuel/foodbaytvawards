import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserRegisterComponent } from './register.component';

const routes: Routes = [
  {
    path: '',
    component: UserRegisterComponent,
    data: { title: 'Register', titleI18n: 'app.register.register' },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RegisterRoutingModule {}
