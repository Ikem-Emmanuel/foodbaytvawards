import { Component, OnDestroy } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NotificationService, AuthenticationService } from '@core';
import { _HttpClient } from '@delon/theme';
import { NzSafeAny } from 'ng-zorro-antd/core/types';
import { NzMessageService } from 'ng-zorro-antd/message';

@Component({
  selector: 'passport-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.less'],
})
export class UserRegisterComponent implements OnDestroy {
  interval$: any;
  constructor(
    fb: FormBuilder,
    private notify: NotificationService,
    private registerService: AuthenticationService,
    private router: Router,
    public http: _HttpClient,
    public msg: NzMessageService,
  ) {
    this.form = fb.group({
      name: [null, [Validators.required]],
      email: [null, [Validators.required, Validators.email]],
      password: [null, [Validators.required, Validators.minLength(6), UserRegisterComponent.checkPassword.bind(this)]],
      password_confirmation: [null, [Validators.required, Validators.minLength(6), UserRegisterComponent.passwordEquar]],
      type: 'USER',
    });
  }

  // #region fields

  loading: boolean = false;

  get name(): AbstractControl {
    return this.form.controls.name;
  }
  get email(): AbstractControl {
    return this.form.controls.email;
  }
  get password(): AbstractControl {
    return this.form.controls.password;
  }
  get password_confirmation(): AbstractControl {
    return this.form.controls.password_confirmation;
  }
  form: FormGroup;
  error = '';
  type = 0;
  userType = 'USER';
  visible = false;
  status = 'pool';
  progress = 0;
  passwordProgressMap: { [key: string]: 'success' | 'normal' | 'exception' } = {
    ok: 'success',
    pass: 'normal',
    pool: 'exception',
  };

  // #endregion

  // #region get captcha

  count = 0;

  static checkPassword(control: FormControl): NzSafeAny {
    if (!control) {
      return null;
    }
    const self: any = this;
    self.visible = !!control.value;
    if (control.value && control.value.length > 9) {
      self.status = 'ok';
    } else if (control.value && control.value.length > 5) {
      self.status = 'pass';
    } else {
      self.status = 'pool';
    }

    if (self.visible) {
      self.progress = control.value.length * 10 > 100 ? 100 : control.value.length * 10;
    }
  }

  static passwordEquar(control: FormControl): { equar: boolean } | null {
    if (!control || !control.parent!) {
      return null;
    }
    if (control.value !== control.parent!.get('password')!.value) {
      return { equar: true };
    }
    return null;
  }

  // #endregion

  submit(): void {
    this.loading = true;
    this.error = '';
    Object.keys(this.form.controls).forEach((key) => {
      this.form.controls[key].markAsDirty();
      this.form.controls[key].updateValueAndValidity();
    });
    if (this.form.invalid) {
      this.loading = false;
      this.error = '';
      return;
    }
    const data = this.form.value;
    // console.log(data);
    this.registerService
      .register(data)
      .then((res) => {
        if (res.status === 'FAILED') {
          // this.error = res.message;
          this.notify.error('', res.message);
          // this.notify.error('', res.error);
          this.loading = false;
          return;
        }
        this.notify.success('', res.message);
        this.loading = false;
        this.router.navigateByUrl('/auth/login');
      })
      .catch((err) => {
        this.loading = false;
        console.warn(err);
      });
  }

  ngOnDestroy(): void {
    if (this.interval$) {
      clearInterval(this.interval$);
    }
  }
}
