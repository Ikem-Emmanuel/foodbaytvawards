import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { _HttpClient } from '@delon/theme';
import { NotificationService, AuthenticationService } from '@core';
import { NzMessageService } from 'ng-zorro-antd/message';

@Component({
  selector: 'app-verification',
  templateUrl: './verification.component.html',
  styleUrls: ['./verification.component.less'],
})
export class VerificationComponent implements OnInit {
  response: any;
  constructor(
    fb: FormBuilder,
    private verificationCodeService: AuthenticationService,
    private reverificationCodeService: AuthenticationService,
    private notify: NotificationService,
    private router: Router,
    public http: _HttpClient,
    public msg: NzMessageService,
  ) {
    this.form = fb.group({
      verifieremail: [null, [Validators.required, Validators.email]],
      verificationcode: [null, [Validators.required, Validators.minLength(5)]],
      email: [null, [Validators.required, Validators.email]],
    });
  }
  ngOnInit(): void {}
  view: boolean = false;
  loading: boolean = false;

  get verifieremail(): AbstractControl {
    return this.form.controls.verifieremail;
  }
  get verificationcode(): AbstractControl {
    return this.form.controls.verificationcode;
  }
  get email(): AbstractControl {
    return this.form.controls.email;
  }
  form: FormGroup;
  error = '';
  type = 0;

  count = 0;
  interval$: any;

  reverify(): void {
    this.error = '';
    this.view = !this.view;
  }

  reverifycode(): void {
    this.loading = true;
    this.error = '';
    this.form.controls.email.markAsDirty();
    this.form.controls.email.updateValueAndValidity();
    if (this.email.invalid) {
      this.loading = false;
      this.error = 'enter a valid email';
      return;
    }
    let body = { email: this.email.value };
    console.log(body);
    this.reverificationCodeService
      .reverificationCode(body)
      .then((res) => {
        if (res.status === 'FAILED') {
          this.error = res.error;
          this.loading = false;
          return;
        }
        this.notify.success('', res.message);
        this.view = !this.view;
        this.loading = false;
      })
      .catch((err) => {
        console.log(err);
        this.loading = false;
      });
  }

  verify(): void {
    this.loading = true;
    this.error = '';
    this.form.controls.verificationcode.markAsDirty();
    this.form.controls.verificationcode.updateValueAndValidity();
    if (this.verificationcode.invalid) {
      this.loading = false;
      this.error = '';
      return;
    }
    let body = {
      token: this.verificationcode.value,
    };
    this.verificationCodeService
      .verificationCode(body)
      .then((res) => {
        if (res.status === 'FAILED') {
          this.notify.error('', res.message);
          this.error = res.message;
          this.loading = false;
          return;
        }
        this.notify.success('', res.message);
        this.router.navigateByUrl('/auth/login');
      })
      .catch((err) => {
        console.log(err);
        this.loading = false;
      });
  }

  // #endregion

  ngOnDestroy(): void {
    if (this.interval$) {
      clearInterval(this.interval$);
    }
  }
}
