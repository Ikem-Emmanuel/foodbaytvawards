import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VerificationRoutingModule } from './verification-routing.module';
import { VerificationComponent } from './verification.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { SHARED_ZORRO_MODULES } from 'src/app/shared/shared-zorro.module';

@NgModule({
  declarations: [VerificationComponent],
  imports: [CommonModule, VerificationRoutingModule, FormsModule, ReactiveFormsModule, TranslateModule, ...SHARED_ZORRO_MODULES],
})
export class VerificationModule {}
